#!/data/data/com.termux/files/usr/bin/bash
# Start WebAgent server inside proot and keep the session alive.
# Derive the project root from THIS script's own location (it sits at the repo
# root) so a custom install folder works; fall back to the default.
PROJECT_ROOT="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
[ -d "$PROJECT_ROOT/.git" ] || PROJECT_ROOT="$HOME/webagent"
cd "$PROJECT_ROOT"

# Launch proot with a persistent bash that starts the server then sleeps
proot-distro login ubuntu --bind "$PROJECT_ROOT:/root/webagent" -- bash -c '
cd /root/webagent
source .venv/bin/activate
nohup python run.py > server_log.txt 2>&1 &
echo $! > /tmp/webagent.pid
echo "Server started with PID $(cat /tmp/webagent.pid)"
# Keep the session alive indefinitely
while true; do
    if ! kill -0 $(cat /tmp/webagent.pid 2>/dev/null) 2>/dev/null; then
        echo "Server died, restarting..."
        nohup python run.py >> server_log.txt 2>&1 &
        echo $! > /tmp/webagent.pid
        echo "Restarted with PID $(cat /tmp/webagent.pid)"
    fi
    sleep 30
done
' &
echo "Launcher PID: $!"
# Record the launcher pid in Termux's writable temp dir. Termux has no writable
# top-level /tmp (it's read-only on Android), so fall back to $TMPDIR ($PREFIX/tmp)
# — writing to /tmp here just printed a harmless "Permission denied". The inner
# /tmp/webagent.pid above is fine: it's written INSIDE the Ubuntu proot, where /tmp
# exists and is writable.
echo $! > "${TMPDIR:-/tmp}/webagent_launcher.pid"
