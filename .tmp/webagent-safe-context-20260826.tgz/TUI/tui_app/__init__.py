"""webagent TUI — a standalone, server-independent server manager agent.

This is a separate project from the web app and from ``launcher/``: a single
self-contained Textual TUI whose agent talks **directly to the LLM API** (never
through the WebAgent server), so it can install, diagnose, repair, and manage a
WebAgent checkout even when the server is down.

v1 scope: the serverless agent with **Codebase Admin** + **Source Control**
abilities operating on a target project directory, with its own external
database (kept separate from the web app's ``app/db/local.db``), plus
**self-update** — it can pull/rebuild and relaunch its own code.
"""

__version__ = "0.2.0"
